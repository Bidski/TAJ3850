1: Install ISP1.13

2: Please unzip 1.13 rc3 patch in your HOME folder. 

NOTE: 
To know where it is, type "echo %HOME%" or "echo %HOMEPATH%" in a command line window.
on Windows it is usually C:\Documents and Settings\username 
on Linux : /home/username. 