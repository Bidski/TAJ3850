#ifndef _MAIN_H_
#define _MAIN_H_

#include <asf.h>
#include "conf_usb.h"
#include "ui.h"
#include "uart.h"
#include "usb_protocol_cdc.h"

#define START_BUTTON_INT_PIN				AVR32_EIC_EXTINT_0_PIN
#define MODE_BUTTON_INT_PIN					AVR32_EIC_EXTINT_1_PIN
#define MPU60X0_BODY_INT_PIN				AVR32_EIC_EXTINT_2_PIN
#define MPU60X0_HEAD_INT_PIN				AVR32_EIC_EXTINT_5_PIN

#define START_BUTTON_INT_FUNCTION			AVR32_EIC_EXTINT_0_FUNCTION
#define MODE_BUTTON_INT_FUNCTION			AVR32_EIC_EXTINT_1_FUNCTION
#define MPU60X0_BODY_INT_FUNCTION			AVR32_EIC_EXTINT_2_FUNCTION
#define MPU60X0_HEAD_INT_FUNCTION			AVR32_EIC_EXTINT_5_FUNCTION

#define START_BUTTON_INT_LINE				AVR32_EIC_INT0
#define MODE_BUTTON_INT_LINE				AVR32_EIC_INT1
#define MPU60X0_BODY_INT_LINE				AVR32_EIC_INT2
#define MPU60X0_HEAD_INT_LINE				AVR32_EIC_INT5

#define START_BUTTON_INT_IRQ				AVR32_EIC_IRQ_0
#define MODE_BUTTON_INT_IRQ					AVR32_EIC_IRQ_1
#define MPU60X0_BODY_INT_IRQ				AVR32_EIC_IRQ_2
#define MPU60X0_HEAD_INT_IRQ				AVR32_EIC_IRQ_5

/*! \brief Opens the communication port
 * This is called by CDC interface when USB Host enable it.
 *
 * \retval true if cdc startup is successfully done
 */
bool main_cdc_enable(uint8_t port);

/*! \brief Closes the communication port
 * This is called by CDC interface when USB Host disable it.
 */
void main_cdc_disable(uint8_t port);

/*! \brief Manages the leds behaviors
 * Called when a start of frame is received on USB line each 1ms.
 */
void main_sof_action(void);

/*! \brief Enters the application in low power mode
 * Callback called when USB host sets USB line in suspend state
 */
void main_suspend_action(void);

/*! \brief Turn on a led to notify active mode
 * Called when the USB line is resumed from the suspend state
 */
void main_resume_action(void);

/*! \brief Save new DTR state to change led behavior.
 * The DTR notify that the terminal have open or close the communication port.
 */
void main_cdc_set_dtr(uint8_t port, bool b_enable);


void vbus_event(bool b_vbus_high);

#endif // _MAIN_H_
