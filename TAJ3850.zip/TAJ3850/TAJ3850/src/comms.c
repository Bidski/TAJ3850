#include <string.h>
#include "main.h"
#include "mpu60X0.h"

/********************************************
 *				CONSTANTS					*
 ********************************************/
#define CONTROL_PORT			0														// USB Virtual COM Port numbers.
#define DATA_PORT				1

#define MPU60X0_PREAMBLE		0x0000													// Preamble for a MPU60X0 packet (from ODROID only).
#define MOTOR_PREAMBLE			0xFFFF													// Preamble for a motor packet.

#define MAX_NUM_MX28			0x20													// Maximum number of MX28 PIDs.
#define NUM_MOTOR_BUSES			3														// Number of individual motor buses.
#define MAX_MOTORS_PER_BUS		10														// Maximum number of motors that can be on one bus (a trivial limit).
#define MAX_MESSAGE_LENGTH		10														// Maximum number of bytes per message.

#define MASTER_ID				-1														// ID of the master device.

/********************************************
 *			FUNCTION PROTOTYPES				*
 ********************************************/
static void		initBuffers(void);
static int		USARTGetChar(volatile avr32_usart_t *usart, uint8_t *value);
static int		initUSART(void);
static int		configUSART(void);
static void		motorBusIntteruptController(uint8_t motorBus);
static void		USART0Interrupt(void);
static void		USART1Interrupt(void);
static void		USART2Interrupt(void);

// Create an array for the USART ISRs.
static void (* const USART_ISR[NUM_MOTOR_BUSES])(void) = {	USART0Interrupt, USART1Interrupt, USART2Interrupt};

/********************************************
 *				GLOBALS						*
 ********************************************/
typedef struct
{
	union
	{
		uint8_t preamble[2];
		uint16_t nPreamble;
	} PREAMBLE;

	uint8_t		nID;																	// ID of the device to send the message to.
	uint8_t		nLength;																// Length of the message after this point.
	uint8_t		nInstruction;															// Instruction to perform. Or returned error if this is a response.
	uint8_t		nParameters[MAX_MESSAGE_LENGTH];										// The parameters for the message. May be none. Upper limit of MAX_MESSAGE_LENGTH.
	uint8_t		nChecksum;																// Check Sum = ~(0xFF & (ID + Length + Error + Parameter1 + ... + Parameter N))
} INSTRUCTION_PACKET;

static usart_options_t			USARTMotorOptions;										// Port options (data bits, stop bits, parity, handshaking, baud rate, etc).

static uint8_t					PIDToBUSMap[MAX_NUM_MX28];								// A mapping between the motor buses and the IDs on each bus.
static INSTRUCTION_PACKET		BUSBuffer[NUM_MOTOR_BUSES][MAX_MOTORS_PER_BUS];			// Allow for one message per motor, per bus, per direction.
static volatile avr32_usart_t	*MOTOR_BUS[NUM_MOTOR_BUSES];								// Handle to each USART device.
static uint16_t					USARTIRQ[NUM_MOTOR_BUSES];								// USART IRQ numbers.

static uint8_t					messageNumberHead[NUM_MOTOR_BUSES];						// Pointers to the head and tail of each message buffer.
static uint8_t					messageNumberTail[NUM_MOTOR_BUSES];

static void initBuffers(void)
{
	memset(BUSBuffer, 0, (NUM_MOTOR_BUSES * MAX_MOTORS_PER_BUS * sizeof(INSTRUCTION_PACKET)));
				
	memset(PIDToBUSMap, 0xFF, (MAX_NUM_MX28 * sizeof(uint8_t)));
				
	MOTOR_BUS[0] = ((avr32_usart_t*)AVR32_USART0_ADDRESS);
	MOTOR_BUS[1] = ((avr32_usart_t*)AVR32_USART1_ADDRESS);
	MOTOR_BUS[2] = ((avr32_usart_t*)AVR32_USART2_ADDRESS);

	USARTIRQ[0] = AVR32_USART0_IRQ;
	USARTIRQ[1] = AVR32_USART1_IRQ;
	USARTIRQ[2] = AVR32_USART2_IRQ;
				
	memset(messageNumberHead, 0, (NUM_MOTOR_BUSES * sizeof(uint8_t)));
	memset(messageNumberTail, 0, (NUM_MOTOR_BUSES * sizeof(uint8_t)));
				
	memset(MPU60X0BodySensorReadings_Raw, 0, (2 * 14 * sizeof(uint8_t)));
	memset(MPU60X0BodySensorReadings_SI,  0, (2 * 7 * sizeof(float)));
}

static int initUSART(void)
{
	uint8_t i;
	
	// Open all motor BUSES.
	for (i = 0; i < NUM_MOTOR_BUSES; i++)
	{
		// Enable interrupt with priority higher than USB
		irq_register_handler(USART_ISR[i], USARTIRQ[i], 3);

		// Initialize it in RS232 mode.
		sysclk_enable_pba_module(USART_SYSCLK);

		if (USART_SUCCESS != usart_init_rs232(MOTOR_BUS[i], &USARTMotorOptions, sysclk_get_pba_hz()))
		{
			return(-1);
		}

		// Enable both RX and TX
		MOTOR_BUS[i]->ier = AVR32_USART_IER_TXRDY_MASK | AVR32_USART_IER_RXRDY_MASK;
	}
	
	return(0);
}

static int configUSART(void)
{
	uint8_t i;
	uint32_t imr;

	USARTMotorOptions.baudrate = LE32_TO_CPU(57600);
	USARTMotorOptions.charlength = 8;
	USARTMotorOptions.paritytype = USART_NO_PARITY;
	USARTMotorOptions.stopbits = USART_1_STOPBIT;
	USARTMotorOptions.channelmode = USART_NORMAL_CHMODE;

	// Open all motor BUSES.
	for (i = 0; i < NUM_MOTOR_BUSES; i++)
	{
		imr = MOTOR_BUS[i]->imr ;
		MOTOR_BUS[i]->idr = 0xFFFFFFFF;
		
		usart_init_rs232(MOTOR_BUS[i], &USARTMotorOptions, sysclk_get_pba_hz());
		
		// Restore both RX and TX
		MOTOR_BUS[i]->ier = imr;
	}
	
	return(0);
}

static int USARTGetChar(volatile avr32_usart_t *usart, uint8_t *value)
{
	int c, ret;
	
	while ((ret = usart_read_char(usart, &c)) == USART_RX_EMPTY)
	{
		;
	}

	if (ret == USART_RX_ERROR)
	{
		return(USART_FAILURE);
	}

	*value = c;
	return(USART_SUCCESS);
}

static void motorBusIntteruptController(uint8_t motorBus)
{
	/*
	// Expected result after a sent command.
	// Total length of message = 3 + length = 3 + (length of data vector) + 2
	struct CommandResult
	{
		uint8_t id = -1;
		uint8_t length = 0;
		uint8_t errorcode = -1;
		std::vector<uint8_t> data;
		uint8_t checksum;
	};
	*/

	uint8_t i, bError;	
	INSTRUCTION_PACKET response;
		
	// There is a response message from one of the motors.
	if (MOTOR_BUS[motorBus]->csr & AVR32_USART_CSR_RXRDY_MASK)
	{
		// Read in an entire response.
		// Have to read in byte-by-byte ..... unfortunately :(
		// We could fail reading in any one of the bytes.
		ui_com_tx_start();

		// Read in the preamble.
		bError = (					 USARTGetChar(MOTOR_BUS[motorBus], &response.PREAMBLE.preamble[0])	== USART_FAILURE)  ? 1 : 0;
		bError = ((bError == 0) &&	(USARTGetChar(MOTOR_BUS[motorBus], &response.PREAMBLE.preamble[1])	== USART_FAILURE)) ? 1 : 0;
		
		// Read in source ID.
		bError = ((bError == 0) &&	(USARTGetChar(MOTOR_BUS[motorBus], &response.nID)					== USART_FAILURE)) ? 1 : 0;
		
		// Read in length of the rest of the packet.
		bError = ((bError == 0) &&	(USARTGetChar(MOTOR_BUS[motorBus], &response.nLength)				== USART_FAILURE)) ? 1 : 0;
		
		// Read in error byte.
		bError = ((bError == 0) &&	(USARTGetChar(MOTOR_BUS[motorBus], &response.nInstruction)			== USART_FAILURE)) ? 1 : 0;
		
		// Read in the parameter data.
		for (i = 0; ((i < (response.nLength - 2)) && (bError == 0)); i++)
		{
			if (USARTGetChar(MOTOR_BUS[motorBus], &response.nParameters[i]) == USART_FAILURE)
			{
				bError = 1;
			}
		}
		
		// Read in the checksum.
		bError = ((bError == 0) &&	(USARTGetChar(MOTOR_BUS[motorBus], &response.nChecksum)				== USART_FAILURE)) ? 1 : 0;
		
		if (bError == 1)
		{
			// An error was encountered somewhere above. Report it.
			usart_reset_status(MOTOR_BUS[motorBus]);
			udi_cdc_multi_signal_framing_error(DATA_PORT);
			ui_com_error();
		}
		
		else
		{
			// No errors.
			// Update PID map if necessary.
			if (PIDToBUSMap[response.nID] != motorBus)
			{
				PIDToBUSMap[response.nID] = motorBus;
			}
		
			// Transfer received packet to CDC TX
			if (!udi_cdc_multi_is_tx_ready(DATA_PORT))
			{
				// Error: FIFO full.
				udi_cdc_multi_signal_overrun(DATA_PORT);
				ui_com_overflow();
			}
		
			else
			{
				// Write received packet to USB port.
				// Write first 5 bytes.
				udi_cdc_multi_write_buf(DATA_PORT, &response, 5);
					
				// Write parameters.
				udi_cdc_multi_write_buf(DATA_PORT, &response.nParameters, response.nLength - 2);
					
				// Write checksum.
				udi_cdc_multi_write_buf(DATA_PORT, &response.nChecksum, 1);
			}
		}
		
		ui_com_tx_stop();
	}

	if (MOTOR_BUS[motorBus]->csr & AVR32_USART_CSR_TXRDY_MASK)
	{
		// If we have data to send.....
		if (messageNumberTail[motorBus] < messageNumberHead[motorBus])
		{
			// Transmit a packet.
			ui_com_rx_start();
		
			// Write packet to USB port.
			usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].PREAMBLE.preamble[0]);
			usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].PREAMBLE.preamble[1]);
			usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].nID);
			usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].nLength);
			usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].nInstruction);

			for (i = 0; i < (BUSBuffer[motorBus][messageNumberTail[motorBus]].nLength - 2); i++)
			{
				usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].nParameters[i]);
			}
			
			usart_write_char(MOTOR_BUS[motorBus], BUSBuffer[motorBus][messageNumberTail[motorBus]].nChecksum);
		
			// Update the tail pointer for the motor bus buffer.
			messageNumberTail[motorBus]++;
		
			if (messageNumberTail[motorBus] == MAX_MOTORS_PER_BUS)
			{
				messageNumberTail[motorBus] = 0;
			}

			else if (messageNumberTail[motorBus] > messageNumberHead[motorBus])
			{
				messageNumberTail[motorBus] = messageNumberHead[motorBus];
			}
			
			ui_com_rx_stop();
		}
	}
}

__attribute__((__interrupt__)) static void USART0Interrupt(void)
{
	motorBusIntteruptController(0);
}

__attribute__((__interrupt__)) static void USART1Interrupt(void)
{
	motorBusIntteruptController(1);
}

__attribute__((__interrupt__)) static void USART2Interrupt(void)
{
	motorBusIntteruptController(2);
}

void uart_rx_notify(uint8_t port)
{
	/*
		enum Instruction {
			PING = 1,
			READ = 2,
			WRITE = 3,
			REG_WRITE = 4,
			ACTION = 5,
			RESET = 6,
			SYNC_WRITE = 131,
			BULK_READ = 146
		};

		// Format of a read command.
		// Total length = 4 + length = 8
		template <typename TType>
		struct ReadCommand
		{
			/// Magic number that heads up every packet
			const uint16_t magic = 0xFFFF;
			/// The ID of the device that we are communicating with
			const uint8_t id;
			/// The total length of the data packet (always 4)
			const uint8_t length = 4;
			/// The instruction that we will be executing (The READ instruction)
			const uint8_t instruction = Instruction::READ;
			/// The address to read from
			const uint8_t address;
			/// The number of bytes to read
			const uint8_t size;
			/// Our checksum for this command
			const uint8_t checksum = calculateChecksum(this);
		};
	   
		// Format of a write command.
		// Total length = 4 + length = 4 + (length of data) + 2
		template <typename TType>
		struct WriteCommand
		{
			/// Magic number that heads up every packet
			const uint16_t magic = 0xFFFF;
			/// The ID of the device that we are communicating with
			const uint8_t id;
			/// The total length of the data packet (3 plus however many bytes we are writing)
			const uint8_t length;
			/// The instruction that we will be executing (The WRITE instruction)
			const uint8_t instruction = Instruction::WRITE;
			/// The address we are writing to
			const uint8_t address;
			/// The bytes that we are writing
			const TType data;
			/// Our checksum for this command
			const uint8_t checksum = calculateChecksum(this);
		};
		
		// Format of a ping command.
		// Total length = 4 + length = 6
		struct PingCommand
		{
			/// Magic number that heads up every packet
			const uint16_t magic = 0xFFFF;
			/// The ID of the device that we are communicating with
			const uint8_t id;
			/// The total length of the data packet (always 2)
			const uint8_t length = 2;
			/// The instruction that we will be executing (The PING instruction)
			const uint8_t instruction = Instruction::PING;
			/// Our checksum for this command
			const uint8_t checksum = calculateChecksum(this);
		};			   
	*/
	
	// Create a buffer for the message.
	iram_size_t numAvailableBytes;
	INSTRUCTION_PACKET message;
	uint32_t imr;
	uint8_t i, busNumber;
	uint8_t MPU60X0Address, gyroFullScale, accelFullScale, DPLFConfig;
	
	// Handle incoming data (from the USB) for specified virtual port.

	// Make sure we can read in the first 2 bytes.
	// This will get us the preamble.
	while ((numAvailableBytes = udi_cdc_multi_get_nb_received_data(DATA_PORT)) < 2)
	{
		;
	}

	// Read in the first 2 bytes.
	udi_cdc_multi_read_buf(DATA_PORT, &(message.PREAMBLE.nPreamble), 2);
	
	switch (port)
	{
		case CONTROL_PORT:
		{
			// Read in and interpret control command. Execute appropriate action.
			// A command has arrived from the PC.
			switch (message.PREAMBLE.nPreamble)
			{
				case MPU60X0_PREAMBLE:
				{
					// Head or body.
					// Gyroscope full scale range.
					// Accelerometer full scale range.
					// DPLF settings.
					// Make sure there are 4 bytes available. One byte for each of the above parameters.
					ui_com_rx_start();
					
					while ((numAvailableBytes = udi_cdc_multi_get_nb_received_data(DATA_PORT)) < 4)
					{
						;
					}

					// Read in the 3 new parameters.
					udi_cdc_multi_read_buf(DATA_PORT, &(MPU60X0Address),	1);
					udi_cdc_multi_read_buf(DATA_PORT, &(gyroFullScale),		1);
					udi_cdc_multi_read_buf(DATA_PORT, &(accelFullScale),	1);
					udi_cdc_multi_read_buf(DATA_PORT, &(DPLFConfig),		1);
					
					ui_com_rx_stop();
					
					// Sanity check the parameters.
					switch (MPU60X0Address)
					{
						case 0:
						default:
						{
							MPU60X0Address = MPU60X0_ADDRESS_BODY;
							break;
						}
						
						case 1:
						{
							MPU60X0Address = MPU60X0_ADDRESS_HEAD;
							break;
						}
					}

					if (gyroFullScale > 3)
					{
						gyroFullScale = -1;
					}
					
					if (accelFullScale > 3)
					{
						accelFullScale = -1;
					}
					
					if (DPLFConfig > 6)
					{
						DPLFConfig = -1;
					}
					
					ui_com_tx_start();
					
					// Reconfigure the MPU60X0s. This will do a complete reconfigure of everything.
					if (configureMPU60X0(MPU60X0Address, gyroFullScale, accelFullScale, DPLFConfig) != 0)
					{
						// TODO: DO SOMETHING HERE!
						// TODO: Send message over control port to indicate failure.
						// TODO: Set an LED to indicate failure?
						ui_com_error();
						ui_com_tx_stop();				
						break;
					}

					ui_com_tx_stop();
					
					break;
				}

				case MOTOR_PREAMBLE:
				{
					ui_com_rx_start();
					
					// Make sure we can read in the next (sizeof(unsigned long) + sizeof(unsigned short) + 2) bytes.
					// This will get us the the baud rate, the char length, the parity, and the number of stop bits.
					while ((numAvailableBytes = udi_cdc_multi_get_nb_received_data(DATA_PORT)) < (sizeof(unsigned long) + sizeof(unsigned short) + 2))
					{
						;
					}

					// Options for USART.
					udi_cdc_multi_read_buf(DATA_PORT, &(USARTMotorOptions.baudrate), sizeof(unsigned long));
					udi_cdc_multi_read_buf(DATA_PORT, &(USARTMotorOptions.charlength), 1);
					udi_cdc_multi_read_buf(DATA_PORT, &(USARTMotorOptions.paritytype), 1);
					udi_cdc_multi_read_buf(DATA_PORT, &(USARTMotorOptions.stopbits), sizeof(unsigned short));

					ui_com_rx_stop();
					
					USARTMotorOptions.channelmode = USART_NORMAL_CHMODE;
					
					// Convert the endianness of the baudrate.
					USARTMotorOptions.baudrate = LE32_TO_CPU(USARTMotorOptions.baudrate);

					// Send configuration details to each of the motor ports.
					for (i = 0; i < NUM_MOTOR_BUSES; i++)
					{
						imr = MOTOR_BUS[i]->imr ;
						MOTOR_BUS[i]->idr = 0xFFFFFFFF;
						usart_init_rs232(MOTOR_BUS[i], &USARTMotorOptions, sysclk_get_pba_hz());
			
						// Restore both RX and TX
						MOTOR_BUS[i]->ier = imr;
					}
			
					break;
				}

				default:
				{
					break;
				}
			}
			
			break;
		}
		
		case DATA_PORT:
		{
			// Read in the message and channel it to the correct motor bus, or trigger a transmission of the current MPU60X0 sensor data.			
			switch (message.PREAMBLE.nPreamble)
			{
				case MPU60X0_PREAMBLE:
				{
					ui_com_tx_start();
					
					// Send the MPU60X0_PREAMBLE followed by the body readings then followed by the sensor readings.
					udi_cdc_multi_write_buf(DATA_PORT, &message.PREAMBLE.nPreamble, 2);
					udi_cdc_multi_write_buf(DATA_PORT, &MPU60X0BodySensorReadings_SI[0], 7 * sizeof(float));
					udi_cdc_multi_write_buf(DATA_PORT, &MPU60X0BodySensorReadings_SI[1], 7 * sizeof(float));

					ui_com_tx_stop();
					
					break;
				}
				
				case MOTOR_PREAMBLE:
				{
					ui_com_rx_start();
					
					// Make sure we have the next two bytes.
					// This will give us the destination ID and the message length.
					while ((numAvailableBytes = udi_cdc_multi_get_nb_received_data(DATA_PORT)) < 2)
					{
						;
					}
			
					udi_cdc_multi_read_buf(DATA_PORT, &(message.nID), 1);
					udi_cdc_multi_read_buf(DATA_PORT, &(message.nLength), 1);

					// Now wait	until we have the rest of the packet available to us.
					while ((numAvailableBytes = udi_cdc_multi_get_nb_received_data(DATA_PORT)) < message.nLength)
					{
						;
					}
				
					// Read in the rest of the packet.
					udi_cdc_multi_read_buf(DATA_PORT, &(message.nInstruction), 1);
					udi_cdc_multi_read_buf(DATA_PORT, message.nParameters, message.nLength - 2);
					udi_cdc_multi_read_buf(DATA_PORT, &(message.nChecksum), 1);
				
					ui_com_rx_stop();
					
					// Locate the correct motor bus.
					busNumber = PIDToBUSMap[message.nID];
					
					if (busNumber != (uint8_t)MASTER_ID)
					{
						// Copy the message to the appropriate buffer and enable the appropriate USART interrupt.
						BUSBuffer[busNumber][messageNumberHead[busNumber]] = message;
						
						// If we have stored the total number of possible messages for this bus
						// wrap around to the beginning.
						if ((++messageNumberHead[busNumber]) == MAX_MOTORS_PER_BUS)
						{
							messageNumberHead[busNumber] = 0;
						}
						
						// If UART is open.
						if (MOTOR_BUS[busNumber]->imr & AVR32_USART_IER_RXRDY_MASK)
						{
							// Enable UART TX interrupt to send a new value.
							MOTOR_BUS[busNumber]->ier = AVR32_USART_IER_TXRDY_MASK;
						}
					}
					
					break;					
				}
				
				default:
				{
					break;
				}
			}
			
			break;
		}

		default:
		{
			break;
		}
	}
}


void uart_config(uint8_t port, usb_cdc_line_coding_t * cfg)
{
	UNUSED(cfg);
	uint8_t i;
	INSTRUCTION_PACKET packet;
		
	// Initialise devices for specified virtual port.
	switch (port)
	{
		case CONTROL_PORT:
		{
			// Set up two? ADCs for battery monitoring.
			// Set up GPIO pin for activating alarm.
			// Set up GPIO pin for disabling power supply.
			// Set up GPIO pins used for back panel interface.
			//		Three buttons (three pins): START, MODE, RESET. Three external interrupts.
			//		Status LEDs
			// Set up registers for controlling system functions.

			break;
		}
		
		case DATA_PORT:
		{
 			// Configure ports with the default parameters.
 			if (configUSART() != 0)
 			{
	 			// TODO: DO SOMETHING HERE!
	 			// TODO: Send message over control port to indicate failure.
	 			// TODO: Set an LED to indicate failure?
	 			ui_com_error();
	 			break;
 			}

			// Set up PID-BUS map. Broadcast a PING command over all 5 USARTs.

			// Prepare the message for the current bus.
			packet.PREAMBLE.nPreamble = MOTOR_PREAMBLE;
			packet.nID = 0xFE;
			packet.nLength = 0x02;
			packet.nInstruction = 0x01;
			packet.nChecksum = 0x00;					// = ~((0xFF + 0xFF + 0xFE + 0x02 + 0x01) & 0xFF) = ~(0x2FF & 0xFF) = ~(0xFF) = 0x00
			
			// Broadcast a PING over all motor BUSES. Each motor will then respond on its connected bus.
			// From this, we can map all PIDs to their respective motor BUSES.
			for (i = 0; i < NUM_MOTOR_BUSES; i++)
			{
				BUSBuffer[i][messageNumberHead[i]] = packet;
				
				if ((++messageNumberHead[i]) == MAX_MOTORS_PER_BUS)
				{
					messageNumberHead[i] = 0;
				}
				
				// If UART is open
				if (MOTOR_BUS[i]->imr & AVR32_USART_IER_RXRDY_MASK)
				{
					// Enable UART TX interrupt to send a new value
					MOTOR_BUS[i]->ier = AVR32_USART_IER_TXRDY_MASK;
				}
			}
/*
			// Initialise MPUs (one for body, one for head?). Program default values.
			if (configureMPU60X0(MPU60X0_ADDRESS_BODY, -1, -1, -1) != 0)
			{
				// TODO: DO SOMETHING HERE!
				// TODO: Send message over control port to indicate failure.
				// TODO: Set an LED to indicate failure?
				ui_com_error();
				break;
			}
*/
			break;
		}

		default:
		{
			break;
		}
	}
}

void uart_open(uint8_t port)
{
	switch (port)
	{
		case CONTROL_PORT:
		{
			// There is nothing to open for this port.
			// The purpose of this port is to accept control signals from the PC
			// and report system status to the PC.
			break;
		}
		
		case DATA_PORT:
		{
			// Initialise arrays.
			initBuffers();
			
 			// Open ports with the default parameters.
			if (initUSART() != 0)
			{
				// TODO: DO SOMETHING HERE!
				// TODO: Send message over control port to indicate failure.
				// TODO: Set an LED to indicate failure?
				ui_com_error();
				break;
			}
/*
			// Open TWI/I2C port with the default set of parameters.
			if (initMPU60X0() != 0)
			{
				// TODO: DO SOMETHING HERE!
				// TODO: Send message over control port to indicate failure.
				// TODO: Set an LED to indicate failure?
				ui_com_error();
				break;
			}
*/			
			break;
		}
	
		default:
		{
			// Do nothing in the default case.
			break;
		}
	}
}

void uart_close(uint8_t port)
{
	uint8_t i, data;
	
	// Clean up buffers for specified virtual port.
	// Close all related devices.
	switch (port)
	{
		case CONTROL_PORT:
		{
			// Disable the two? ADCs used for battery monitoring.
			// Release GPIO pin used for activating alarm.
			// Release GPIO pin used for disabling power supply.
			// Release GPIO pins used for back panel interface.
			//		Three buttons (three pins): START, MODE, RESET. Three external interrupts.
			//		Status LEDs
			// Release allocated used for registers for controlling system functions.
			break;
		}
		
		case DATA_PORT:
		{
			// Close all USARTs for communication with the motors.
			for (i = 0; i < NUM_MOTOR_BUSES; i++)
			{
				MOTOR_BUS[i]->idr = 0xFFFFFFFF;
			}
/*			
			// Put MPUs into sleep mode.
			data = MPU60X0_MPU60X0_SLEEP_MODE;
			
			if (sendMPUPacket(MPU60X0_ADDRESS_BODY, MPU60X0_PWR_MGMT_1, &data, 1) != 0)
			{
				// TODO: DO SOMETHING HERE!
				// TODO: Send message over control port to indicate failure.
				// TODO: Set an LED to indicate failure?
				ui_com_error();
				break;
			}

			// Close TWI/I2C port.
			(&AVR32_TWI)->idr = 0xFFFFFFFF;

			eic_disable_line(&AVR32_EIC, MPU60X0_BODY_INT_LINE);
			eic_disable_line(&AVR32_EIC, MPU60X0_HEAD_INT_LINE);
*/			
			// Clear sensor reading buffers.
			// Clear PID-BUS map buffer.
			// Clear bus buffers.
			initBuffers();

			break;
		}

		default:
		{
			// Nothing to do here.
			break;
		}
	}
}
