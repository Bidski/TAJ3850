#ifndef _ASF_H
#define _ASF_H

/*
 * This file includes all API header files for the selected drivers from ASF.
 * Note: There might be duplicate includes required by more than one driver.
 *
 * The file is automatically generated and will be re-written when
 * running the ASF driver selector tool. Any changes will be discarded.
 */

// From module: Compiler abstraction layer and code utilities
#include <compiler.h>
#include <status_codes.h>

// From module: CPU Cycle Counter
#include <cycle_counter.h>

// From module: EIC - External Interrupt Controller
#include <eic.h>

// From module: EVK1101
#include <led.h>

// From module: FLASHC - Flash Controller
#include <flashc.h>

// From module: GPIO - General-Purpose Input/Output
#include <gpio.h>

// From module: Generic board support
#include <board.h>

// From module: INTC - Interrupt Controller
#include <intc.h>

// From module: Interrupt management - UC3 implementation
#include <interrupt.h>

// From module: PM Power Manager- UC3 A0/A1/A3/A4/B0/B1 implementation
#include <power_clocks_lib.h>
#include <sleep.h>

// From module: Part identification macros
#include <parts.h>

// From module: TWI - Two-Wire Interface
#include <twi.h>

// From module: Sleep manager - UC3 implementation
#include <sleepmgr.h>
#include <uc3/sleepmgr.h>

// From module: System Clock Control - UC3 B0 implementation
#include <sysclk.h>

// From module: USART - Universal Synchronous/Asynchronous Receiver/Transmitter
#include <usart.h>

// From module: USB CDC Protocol
#include <usb_protocol_cdc.h>

// From module: USB Device CDC (Single Interface Device)
#include <udi_cdc.h>

// From module: USB Device Stack Core (Common API)
#include <udc.h>
#include <udd.h>

#include <pm.h>

#endif // _ASF_H
