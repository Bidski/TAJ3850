#include "main.h"

static volatile bool main_b_cdc_enable = false;

/*! \brief Main function. Execution starts here.
 */
int main(void)
{
/*
	eic_options_t eic_options;

	// Create a mapping between the GPIO pins and the required devices.
	static const gpio_map_t GPIO_MAP =
	{
		{AVR32_ADC_AD_4_PIN,		AVR32_ADC_AD_4_FUNCTION},			// Battery Monitor
		{AVR32_EIC_EXTINT_0_PIN,	AVR32_EIC_EXTINT_0_FUNCTION},		// START Button
		{AVR32_EIC_EXTINT_1_PIN,	AVR32_EIC_EXTINT_1_FUNCTION},		// MODE Button
		{AVR32_TWI_SDA_0_0_PIN,		AVR32_TWI_SDA_0_0_FUNCTION},		// MPU60X0
		{AVR32_TWI_SCL_0_0_PIN,		AVR32_TWI_SCL_0_0_FUNCTION},
		{AVR32_USART0_CLK_0_0_PIN,	AVR32_USART0_CLK_0_0_FUNCTION},		// MOTOR BUS 1
		{AVR32_USART0_TXD_0_0_PIN,	AVR32_USART0_TXD_0_0_FUNCTION},
		{AVR32_USART0_RXD_0_0_PIN,	AVR32_USART0_RXD_0_0_FUNCTION},
		{AVR32_USART0_CTS_0_PIN,	AVR32_USART0_CTS_0_FUNCTION},
		{AVR32_USART0_RTS_0_PIN,	AVR32_USART0_RTS_0_FUNCTION},
		{AVR32_USART1_CLK_0_PIN,	AVR32_USART1_CLK_0_FUNCTION},		// MOTOR BUS 2
		{AVR32_USART1_TXD_0_1_PIN,	AVR32_USART1_TXD_0_1_FUNCTION},
		{AVR32_USART1_RXD_0_1_PIN,	AVR32_USART1_RXD_0_1_FUNCTION},
		{AVR32_USART1_CTS_0_0_PIN,	AVR32_USART1_CTS_0_0_FUNCTION},
		{AVR32_USART1_RTS_0_0_PIN,	AVR32_USART1_RTS_0_0_FUNCTION},
		{AVR32_USART2_CLK_0_PIN,	AVR32_USART2_CLK_0_FUNCTION},		// MOTOR BUS 3
		{AVR32_USART2_TXD_0_0_PIN,	AVR32_USART2_TXD_0_0_FUNCTION},
		{AVR32_USART2_RXD_0_0_PIN,	AVR32_USART2_RXD_0_0_FUNCTION},
		{AVR32_USART2_CTS_0_PIN,	AVR32_USART2_CTS_0_FUNCTION},
		{AVR32_USART2_RTS_0_PIN,	AVR32_USART2_RTS_0_FUNCTION},
		{START_BUTTON_INT_PIN,		START_BUTTON_INT_FUNCTION},			// External Interrupt for START button.
		{MODE_BUTTON_INT_PIN,		MODE_BUTTON_INT_FUNCTION},			// External Interrupt for MODE button.
		{MPU60X0_BODY_INT_PIN,		MPU60X0_BODY_INT_FUNCTION},			// External Interrupt for MPU60X0 body.
		{MPU60X0_HEAD_INT_PIN,		MPU60X0_HEAD_INT_FUNCTION}			// External Interrupt for MPU60X0 head.
		{AVR32_TWI_SDA_0_0_PIN,		AVR32_TWI_SDA_0_0_FUNCTION},		// MPU60X0
		{AVR32_TWI_SCL_0_0_PIN,		AVR32_TWI_SCL_0_0_FUNCTION}
	};
*/
  
	// Switch to oscillator 0
//	pm_switch_to_osc0(&AVR32_PM, FOSC0, OSC0_STARTUP);

	irq_initialize_vectors();
	cpu_irq_enable();

	// Initialize the sleep manager
	sleepmgr_init();

	sysclk_init();
	board_init();
	ui_init();
	ui_powerdown();

	// Start USB stack to authorize VBus monitoring.
	udc_start();

/*
	// GPIO pin configurations.
	gpio_enable_module(GPIO_MAP, sizeof(GPIO_MAP) / sizeof(GPIO_MAP[0]));

	// Enable edge-triggered interrupt.
	eic_options.eic_mode   = EIC_MODE_EDGE_TRIGGERED;
	
	// Interrupt will trigger on rising edge.
	eic_options.eic_level  = EIC_EDGE_RISING_EDGE;
	
	// Disable filter.
	eic_options.eic_filter = EIC_FILTER_DISABLED;
	
	// For Wake Up mode, initialize in asynchronous mode
	eic_options.eic_async  = EIC_ASYNCH_MODE;
	
	// Choose External Interrupt Controller Line
	eic_options.eic_line   = MPU60X0_BODY_INT_LINE;

	// Init the EIC controller with the options
	eic_init(&AVR32_EIC, &eic_options, 1);
	
	// Choose External Interrupt Controller Line
	eic_options.eic_line   = MPU60X0_HEAD_INT_LINE;

	// Init the EIC controller with the options
	eic_init(&AVR32_EIC, &eic_options, 1);
*/

	// The main loop manages only the power mode
	// because the USB management is done by interrupt
	while (true)
	{
		sleepmgr_enter_sleep();
	}
}

void main_suspend_action(void)
{
	ui_powerdown();
}

void main_resume_action(void)
{
	ui_wakeup();
}

void main_sof_action(void)
{
	if (!main_b_cdc_enable)
	{
		return;
	}
	
	ui_process(udd_get_frame_number());
}

bool main_cdc_enable(uint8_t port)
{
	main_b_cdc_enable = true;
	
	// Open communication
	uart_open(port);
	
	return(true);
}

void main_cdc_disable(uint8_t port)
{
	main_b_cdc_enable = false;
	
	// Close communication
	uart_close(port);
}

void main_cdc_set_dtr(uint8_t port, bool b_enable)
{
	if (b_enable)
	{
		// Host terminal has open COM
		ui_com_open(port);
	}
	
	else
	{
		// Host terminal has close COM
		ui_com_close(port);
	}
}

void vbus_event(bool b_vbus_high)
{
	if (b_vbus_high)
	{
		// Connect USB device
		udc_attach();
	}
	
	else
	{
		// Disconnect USB device
		udc_detach();
	}
}