/**
 * \file
 *
 * \brief USB configuration file for CDC application
 *
 * Copyright (c) 2009-2013 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#ifndef _CONF_USB_H_
#define _CONF_USB_H_

#include "compiler.h"
#include "board.h"

/**
 * USB Device Configuration
 * @{
 */

//! Device definition (mandatory)
#define  USB_DEVICE_VENDOR_ID					USB_VID_ATMEL

#if BOARD == UC3B_BOARD_CONTROLLER
	#define  USB_DEVICE_PRODUCT_ID				USB_PID_ATMEL_UC3_CDC_DEBUG
#else
	#define  USB_DEVICE_PRODUCT_ID				USB_PID_ATMEL_ASF_TWO_CDC
#endif

#define  USB_DEVICE_MAJOR_VERSION         1
#define  USB_DEVICE_MINOR_VERSION         0
#define  USB_DEVICE_POWER                 100 // Consumption on Vbus line (mA)
#define  USB_DEVICE_ATTR                  \
	(USB_CONFIG_ATTR_SELF_POWERED)
// (USB_CONFIG_ATTR_BUS_POWERED)
//	(USB_CONFIG_ATTR_REMOTE_WAKEUP|USB_CONFIG_ATTR_SELF_POWERED)
//	(USB_CONFIG_ATTR_REMOTE_WAKEUP|USB_CONFIG_ATTR_BUS_POWERED)

//! USB Device string definitions (Optional)
#define  USB_DEVICE_MANUFACTURE_NAME      /*"ATMEL ASF"*/		"NUBots"
#define  USB_DEVICE_PRODUCT_NAME          /*"CDC Virtual Com"*/	"TAJ3850"
// #define  USB_DEVICE_SERIAL_NAME           "12...EF"


/**
 * Device speeds support
 * Low speed not supported by CDC
 * @{
 */
//! To authorize the High speed
#if (UC3A3||UC3A4)
	#define  USB_DEVICE_HS_SUPPORT
	
#elif (SAM3XA||SAM3U)
	#define  USB_DEVICE_HS_SUPPORT

	// ADDED
	// In HS mode, size of bulk endpoints are 512 by default.
	// If CDC endpoints all uses 2 banks, DPRAM is not enough: 4 bulk
	// endpoints requires 4K bytes. So reduce the number of banks of CDC bulk
	// endpoints to use less DPRAM.
	#if defined(USB_DEVICE_HS_SUPPORT)
		#define  UDD_BULK_NB_BANK(ep) (1)
	#endif
#endif
//@}


/**
 * USB Device Callbacks definitions (Optional)
 * @{
 */
#define  UDC_VBUS_EVENT(b_vbus_high)		vbus_event(b_vbus_high)
#define  UDC_SOF_EVENT()					main_sof_action()
#define  UDC_SUSPEND_EVENT()				main_suspend_action()
#define  UDC_RESUME_EVENT()					main_resume_action()
//! Mandatory when USB_DEVICE_ATTR authorizes remote wakeup feature
// #define  UDC_REMOTEWAKEUP_ENABLE()        user_callback_remotewakeup_enable()
// extern void user_callback_remotewakeup_enable(void);
// #define  UDC_REMOTEWAKEUP_DISABLE()       user_callback_remotewakeup_disable()
// extern void user_callback_remotewakeup_disable(void);
//! When a extra string descriptor must be supported
//! other than manufacturer, product and serial string
// #define  UDC_GET_EXTRA_STRING()
//@}

//@}


/**
 * USB Device low level configuration
 * For device that does not use default settings, e.g.,
 * number of banks for each bulk endpoint (default is 2).
 * @{
 */

#if defined(USB_DEVICE_HS_SUPPORT)
	// In HS mode, size of bulk endpoints are 512
	// If all CDC endpoints use 2 banks, DPRAM is not enough: 4 bulk
	// endpoints requires 4K bytes. So reduce the number of banks of CDC bulk
	// endpoints to use less DPRAM.
	#define  UDD_BULK_NB_BANK(ep) (1)
#endif
//@}


/**
 * USB Interface Configuration
 * @{
 */
/**
 * Configuration of CDC interface
 * @{
 */

//! Define two USB communication ports
#define  UDI_CDC_PORT_NB 2

//! Interface callback definition
#define  UDI_CDC_ENABLE_EXT(port)         main_cdc_enable(port)
#define  UDI_CDC_DISABLE_EXT(port)        main_cdc_disable(port)
#define  UDI_CDC_RX_NOTIFY(port)          uart_rx_notify(port)
#define  UDI_CDC_TX_EMPTY_NOTIFY(port)
#define  UDI_CDC_SET_CODING_EXT(port,cfg) uart_config(port, cfg)
#define  UDI_CDC_SET_DTR_EXT(port,set)    main_cdc_set_dtr(port, set)
#define  UDI_CDC_SET_RTS_EXT(port,set)

//! Define it when the transfer CDC Device to Host is a low rate (<512000 bauds)
//! to reduce CDC buffers size
//#define  UDI_CDC_LOW_RATE				// UNCOMMENTED

//! Default configuration of communication port
#define  UDI_CDC_DEFAULT_RATE				115200	/*20000000		// Should be 20M baud*/
#define  UDI_CDC_DEFAULT_STOPBITS			CDC_STOP_BITS_1
#define  UDI_CDC_DEFAULT_PARITY				CDC_PAR_NONE
#define  UDI_CDC_DEFAULT_DATABITS			8
//@}
//@}

#define UDI_COMPOSITE_DESC_T \
   usb_iad_desc_t udi_cdc_iad; \
   udi_cdc_comm_desc_t udi_cdc_comm0; \
   udi_cdc_data_desc_t udi_cdc_data0; \
   udi_cdc_comm_desc_t udi_cdc_comm1; \
   udi_cdc_data_desc_t udi_cdc_data1;

#define UDI_COMPOSITE_DESC_FS \
   .udi_cdc_iad                = UDI_CDC_IAD_DESC_0, \
   .udi_cdc_comm0              = UDI_CDC_COMM_DESC_0, \
   .udi_cdc_data0              = UDI_CDC_DATA_DESC_0_FS, \
   .udi_cdc_comm1              = UDI_CDC_COMM_DESC_1, \
   .udi_cdc_data1              = UDI_CDC_DATA_DESC_1_FS

#define UDI_COMPOSITE_DESC_HS \
   .udi_cdc_iad               = UDI_CDC_IAD_DESC_0, \
   .udi_cdc_comm0             = UDI_CDC_COMM_DESC_0, \
   .udi_cdc_data0             = UDI_CDC_DATA_DESC_0_HS, \
   .udi_cdc_comm1             = UDI_CDC_COMM_DESC_1, \
   .udi_cdc_data1             = UDI_CDC_DATA_DESC_1_HS

#define UDI_COMPOSITE_API \
   &udi_api_cdc_comm,       \
   &udi_api_cdc_data,       \
   &udi_api_cdc_comm,       \
   &udi_api_cdc_data

/**
 * USB Device Driver Configuration
 * @{
 */
//@}

//! The includes of classes and other headers must be done at the end of this file to avoid compile error
#include "udi_cdc_conf.h"
#include "uart.h"
#include "main.h"

#endif // _CONF_USB_H_
