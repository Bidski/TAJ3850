#include "main.h"
#include "mpu60X0.h"

int initMPU60X0(void)
{
	twi_options_t opt;
	
	opt.pba_hz = FOSC0;
	opt.speed  = MPU60X0_SPEED;
	opt.chip   = MPU60X0_BASE_ADDRESS;

	// Enable External Interrupt Controller Line.
	eic_enable_line(&AVR32_EIC, MPU60X0_BODY_INT_LINE);
	eic_enable_line(&AVR32_EIC, MPU60X0_HEAD_INT_LINE);

	// Enable interrupts with priority higher than USB.
	irq_register_handler(MPU60X0BodyInterrupt, MPU60X0_BODY_INT_IRQ, 3);
	irq_register_handler(MPU60X0HeadInterrupt, MPU60X0_HEAD_INT_IRQ, 3);

	// Initialize TWI driver with options.
	if (TWI_SUCCESS != twi_master_init(&AVR32_TWI, &opt))
	{
		return(-1);
	}

	// Enable both RX and TX
	(&AVR32_TWI)->ier = AVR32_TWI_IER_TXRDY_MASK | AVR32_TWI_IER_RXRDY_MASK;

	return(0);
}

int configureMPU60X0(int8_t mpuAddress, int8_t gyroFullScale, int8_t accelFullScale, int8_t DPLFConfig)
{
	uint8_t data;
	
	// Send a device reset and tell the device to derive its clock from a PLL using the X-axis of the gyroscope as a base.
	data = MPU60X0_PWR_MGMT_1_BYTE;
	
	if (sendMPUPacket(mpuAddress, MPU60X0_PWR_MGMT_1, &data, 1) != 0)
	{
		return(-1);
	}
	
	// Delay for 100ms.
	cpu_delay_ms(100, sysclk_get_cpu_hz());

	// Send the signal path reset byte.
	// Just to ensure the entire device has been reset.
	data = MPU60X0_SIGNAL_PATH_RESET_BYTE;
	
	if (sendMPUPacket(mpuAddress, MPU60X0_SIGNAL_PATH_RESET, &data, 1) != 0)
	{
		return(-1);
	}
	
	// Delay for 100ms.
	cpu_delay_ms(100, sysclk_get_cpu_hz());

	// Send the configuration byte.
	// Set EXT_SYNC off and DLPF to 260Hz bandwidth or a user defined value.
	data = (DPLFConfig > -1) ? (((MPU60X0_CONFIG_BYTE) & 0xF8) | DPLFConfig) : MPU60X0_CONFIG_BYTE;
	
	if (sendMPUPacket(mpuAddress, MPU60X0_CONFIG, &data, 1) != 0)
	{
		return(-1);
	}
	
	// Configure the gyroscope.
	// Set the full scale range of the gyroscope to GYRO_FS_SEL (defined in header file) or a user defined value.
	data = (gyroFullScale > -1) ? (((MPU60X0_GYRO_CONFIG_BYTE) & 0xE3) | (gyroFullScale << 3)) : MPU60X0_GYRO_CONFIG_BYTE;
	
	if (sendMPUPacket(mpuAddress, MPU60X0_GYRO_CONFIG, &data, 1) != 0)
	{
		return(-1);
	}
	
	// Configure the accelerometer.
	// Set the full scale range of the accelerometer to ACCEL_FS_SEL (defined in header file) or a user defined value.
	data = (accelFullScale > -1) ? (((MPU60X0_ACCEL_CONFIG_BYTE) & 0xE3) | (accelFullScale << 3)) : MPU60X0_ACCEL_CONFIG_BYTE;
	
	if (sendMPUPacket(mpuAddress, MPU60X0_ACCEL_CONFIG, &data, 1) != 0)
	{
		return(-1);
	}
	
	// Configure the interrupt generation byte.
	// Set the MPU60X0 to only generate interrupts when a set of sensor readings are available.
	data = MPU60X0_INT_ENABLE_BYTE;
	
	if (sendMPUPacket(mpuAddress, MPU60X0_INT_ENABLE, &data, 1) != 0)
	{
		return(-1);
	}

	return(0);
}

int8_t sendMPUPacket(int8_t mpuAddress, uint8_t mpuRegisterAddress, void *data, uint8_t dataLength)
{
	twi_package_t packet;
	int8_t bError = 0;
	
	// Address the MPU in the body.
	packet.chip = mpuAddress;
	
	// We want to write to the PWR_MGMT_1 register.
	packet.addr[0] = mpuRegisterAddress;
	packet.addr[1] = 0;
	packet.addr[2] = 0;
	
	// It is a 1 byte address.
	packet.addr_length = 1;

	// Write a byte telling the MPU to reset and use a PLL clock derived
	// from the X-axis of the gyroscope.
	packet.buffer = data;

	// How many bytes do we want to write.
	packet.length = dataLength;

	ui_com_tx_start();
	
	if (TWI_SUCCESS != twi_master_write(&AVR32_TWI, &packet))
	{
		bError = -1;
	}
	
	ui_com_tx_stop();
	
	return(bError);
}

int requestMPUPacket(int8_t mpuAddress, uint8_t mpuRegisterAddress, void *data, uint8_t dataLength)
{
	twi_package_t packet;
	int8_t bError = 0;

	// Address the MPU in the body.
	packet.chip = mpuAddress;
	
	// We want to write to the PWR_MGMT_1 register.
	packet.addr[0] = mpuRegisterAddress;
	packet.addr[1] = 0;
	packet.addr[2] = 0;
	
	// It is a 1 byte address.
	packet.addr_length = 1;

	// Write a byte telling the MPU to reset and use a PLL clock derived
	// from the X-axis of the gyroscope.
	packet.buffer = data;

	// How many bytes do we want to write.
	packet.length = dataLength;

	ui_com_rx_start();
	
	if (TWI_SUCCESS != twi_master_read(&AVR32_TWI, &packet))
	{
		bError = -1;
	}
	
	ui_com_rx_stop();
	
	return(bError);
}

void MPU60X0IntteruptController(uint8_t mpuAddress, uint8_t sensor)
{
	uint8_t bError;
	
	ui_com_rx_start();
	
	// Request sensor readings.
	bError = (					 requestMPUPacket(mpuAddress,  GYRO_XOUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 0], 1) == -1)  ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,  GYRO_XOUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 1], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,  GYRO_YOUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 2], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,  GYRO_YOUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 3], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,  GYRO_ZOUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 4], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,  GYRO_ZOUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 5], 1) == -1)) ? 1 : 0;
	
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress, ACCEL_XOUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 6], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress, ACCEL_XOUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 7], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress, ACCEL_YOUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 8], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress, ACCEL_YOUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[ 9], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress, ACCEL_ZOUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[10], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress, ACCEL_ZOUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[11], 1) == -1)) ? 1 : 0;
	
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,   TEMP_OUT_H, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[12], 1) == -1)) ? 1 : 0;
	bError = ((bError == 0) &&	(requestMPUPacket(mpuAddress,   TEMP_OUT_L, &MPU60X0BodySensorReadings_Raw[sensor].byteAccess[13], 1) == -1)) ? 1 : 0;
	
	if (bError != 0)
	{
		ui_com_error();
		return;
	}
	
	// Convert readings to SI units.
	MPU60X0BodySensorReadings_SI[sensor][0] = MPU60X0BodySensorReadings_Raw[sensor].shortAccess[0] * GRAVITY;
	MPU60X0BodySensorReadings_SI[sensor][1] = MPU60X0BodySensorReadings_Raw[sensor].shortAccess[1] * GRAVITY;
	MPU60X0BodySensorReadings_SI[sensor][2] = MPU60X0BodySensorReadings_Raw[sensor].shortAccess[2] * GRAVITY;
	
	MPU60X0BodySensorReadings_SI[sensor][3] = MPU60X0BodySensorReadings_Raw[sensor].shortAccess[3] * RADIANS_PER_DEGREE;
	MPU60X0BodySensorReadings_SI[sensor][4] = MPU60X0BodySensorReadings_Raw[sensor].shortAccess[4] * RADIANS_PER_DEGREE;
	MPU60X0BodySensorReadings_SI[sensor][5] = MPU60X0BodySensorReadings_Raw[sensor].shortAccess[5] * RADIANS_PER_DEGREE;

	MPU60X0BodySensorReadings_SI[sensor][6] = CONVERT_TEMP_READING(MPU60X0BodySensorReadings_Raw[sensor].shortAccess[6]);
	
	ui_com_rx_stop();
}

__attribute__((__interrupt__)) void MPU60X0BodyInterrupt(void)
{
	MPU60X0IntteruptController(MPU60X0_ADDRESS_BODY, 0);
}

__attribute__((__interrupt__)) void MPU60X0HeadInterrupt(void)
{
	MPU60X0IntteruptController(MPU60X0_ADDRESS_HEAD, 1);
}

